<?php include('logindb.php') ?>

<!DOCTYPE html>
<html>
<body>

<h2>Login</h2>

<div id="loginform">
    <form action="login.php" method="post">
        <p>Please login to continue:</p>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required/> <br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required/> <br>
         <button type="submit" name="login_enter">Login</button>
        
        
        <a href="signup.php" id="signup">I do not have an account.</a>
    </form>
</div>

 

</body>
</html>
