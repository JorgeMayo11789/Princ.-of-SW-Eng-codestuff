<?php 
session_start();

//Connect to database


// Do not change the following two lines.
$teamURL = dirname($_SERVER['PHP_SELF']) . DIRECTORY_SEPARATOR;
$server_root = dirname($_SERVER['PHP_SELF']);

// You will need to require this file on EVERY php file that uses the database.
// Be sure to use $db->close(); at the end of each php file that includes this!

$dbhost = 'localhost';  // Most likely will not need to be changed
$dbname = 'iosias';   // Needs to be changed to your designated table database name
$dbuser = 'iosias';   // Needs to be changed to reflect your LAMP server credentials
$dbpass = 'eileen11'; // Needs to be changed to reflect your LAMP server credentials

$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if($mysqli->connect_errno > 0) {
    die('Unable to connect to database [' . $mysqli->connect_error . ']');
}
    //Connect to database 2

$dbhost2 = 'localhost';  // Most likely will not need to be changed
$dbname2 = 'ankeze2016';   // Needs to be changed to your designated table database name
$dbuser2 = 'ankeze2016';   // Needs to be changed to reflect your LAMP server credentials
$dbpass2 = 'flavien2012'; // Needs to be changed to reflect your LAMP server credentials

$mysqli2 = new mysqli($dbhost2, $dbuser2, $dbpass2, $dbname2);

if($mysqli2->connect_errno > 0) {
    die('Unable to connect to database [' . $mysqli2->connect_error . ']');
}




        $studentname   = $_SESSION['user']['FirstName'];
        $studentid   =   $_SESSION['user']['ID'];



        $eventid = $_POST['postid'];


//if ( isset( $_POST['id2'] ) ) {
//	echo "JS says " . $_POST['id2']; // Outputs : JS says Hi!
//} 



  //    echo '<script language="javascript">';
   //    echo 'alert($eventid)';
   //     echo '</script>';
    //  echo $eventid;

     /*************************************************************  From  ***************************************************/
     /******INSERT NEW SCHEDULE IN TABLE*****/

//IF CONNECTION SUCCESSFUL 
/*if(isset($_POST['add']))
{ 
    global $mysqli2, $mysqli, $username, $tutorid;
    
    
     $eventName   = $_POST['inputName'];
     $day         = $_POST['inputDay'];
     $times       = $_POST['inputTimes'];
     $description = $_POST['inputDescription'];
    
   */ 
    
    //VARIABLES    
   /* $firstname = $mysqli->real_escape_string($_POST['firstname']);
    $username = $mysqli->real_escape_string($_POST['username']);
    $salt1 = "qm&h*"; $salt2 = "pg!@";
    $token = $_POST['password'];
    $password = hash('ripemd128', "$salt1$token$salt2"); 
    $type = $mysqli->real_escape_string($_POST['type']);
    $query = "SELECT Username FROM Users where Username='".$username."'";
    $result = mysqli_query($mysqli,$query);
    $numResults = mysqli_num_rows($result); */
       
    
    
  /*  if($numResults>=1)
    {
        $message = $username." Username already exist!!";
        
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
    else
    { */
    
    
        mysqli_query($mysqli2, "UPDATE availabilityShcedule SET Status = 'B', BookedById = '$studentid' WHERE ID = '$eventid'");
        
      //  $message = "Added Sucessfully!!";
        
     //   echo "<script type='text/javascript'>alert('$message');</script>";
     //   header('location: ../dashboard/student.php');
        //  header("location: ../homepage/index.php");
       
      /*  $strSQL = mysqli_query($mysqli,"SELECT * FROM Users WHERE Username='$username' and Password='$password'");
        $Results = mysqli_fetch_array($strSQL); 
        
        
        
        
        
        // check if user is tutor or student
        // $logged_in_user = mysqli_fetch_assoc($strSQL);
        if ($Results['Type'] == 'tutor') {

            $_SESSION['user'] = $Results;
            $_SESSION['success']  = "You are now logged in";
            header('location: ../dashboard/tutor.php');		  
        }
        else{

            $_SESSION['user'] = $Results;
            $_SESSION['success']  = "You are now logged in";

            header('location: ../dashboard/student.php');
        } 
        
        
    } */
        
//}
























             
 //   $sql =   ("INSERT INTO Schedule (TutorName, Day, Times) VALUES ('$tutorname', '$days','$times')");

 //   $id =   ("SELECT ID FROM Schedule WHERE (TutorName = '$tutorname' AND Day = '$days' AND Times = '$times')");

             
//if ($mysqli->query($sql) === TRUE ) {
  	 
    
    
    
    
//	} else {
//	    echo "Error: " . $sql . "<br>" . $conn->error;
//	}

?>