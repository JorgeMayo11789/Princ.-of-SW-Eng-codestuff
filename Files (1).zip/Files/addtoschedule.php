<?php 
//Database connection
 try{
        $servername = "localhost";
        //CONNECT TO DATABASE
        $username = "jmayoral2017";
        $password = "gQ52FJ9MRr";
        $conn = new mysqli($servername, $username, $password, $username);
        $days = $_POST['postdays'];
        $times = $_POST['posttimes'];     
     /*************************************************************  From  ***************************************************/
          /******FIND THE INDEX FROM TABLE*****/
            
         $sql = ("INSERT INTO Schedule VALUES(1, 'Jorge', '$days','$times','Student','Test')");
	if ($conn->query($sql) === TRUE) {
  	  echo "New record created successfully";
	} else {
	    echo "Error: " . $sql . "<br>" . $conn->error;
	}
}
    catch(PDOException $e){
        
        //echo "Connection failed: " . $e->getMessage();
        echo '<script language="javascript">';
        echo 'alert("Connection failed")';
        echo '</script>';
    }
?>