<?php 
//Database connection
 try{
        $servername = "localhost";
        //CONNECT TO DATABASE
        $username = "jmayoral2017";
        $password = "gQ52FJ9MRr";
        $conn = new
        PDO ("mysql:host=$servername;dbname=jmayoral2017", trim($username), trim($password));
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO :: ERRMODE_EXCEPTION);
        $from = $_POST['postfrom'];
        $to = $_POST['postto'];
        $word = $_POST['postword'];
        //$word2 = nl2br($word);
     
    // foreach ($word as $string) {
         
     //       echo $string;
     //}
     
    // echo $word2;
     
     $fword = "";
     
    // $word3 = explode(" ",$word); // turn input string into an array
     
     $word3 = preg_split("/[\s,]+/", $word);
     
     
    // foreach ($word3 as $word4) {
         
       //  echo $word4."<br>";
         
      //   if ($word4 == "Paste"){
             
         //    $fword .= " "."Peteeeeeeeer";
              //echo $word3;
    //     }
    //     else{ 
           //  $fword .= " ". $word4;
    //     }
   //  }
    // echo $fword;  
     
     /*************************************************************  From  ***************************************************/
        if($from == "c++")
        {
           $from = "Cplusplus";
        }
        elseif($from == "java")
        {
            $from = "Java";
        }
       elseif($from == "c")
        {
            $from = "C";
        }
         elseif($from == "c#")
        {
            $from = "Csharp";
        }
      elseif($from == "python")
        {
            $from = "Python";
        }
          
        if ($from != null){
          /******FIND THE INDEX FROM TABLE*****/
           foreach ($word3 as $word4) {  
            
            
                    $index = $conn->prepare("SELECT Languages.ID FROM
                    Languages WHERE $from = '$word4' ");         //= '$word4'  LIKE '%$word4%'
                    $index->execute();
                    $flag = $index->setFetchMode (PDO :: FETCH_ASSOC);
                    $result2= $index->fetchAll();

                    $row1   = '';
                    $fIndex = '';

                    if (count($result2) == 0 ){
                       // echo "Incorrect Input";

                    }
                    else{

                      $row1 = $result2[0];  
                      $fIndex = $row1["ID"];       
                    /******SEQUENCE OF IF_ELSE STATMENTS TO FIND THE TRANSLATION IN "TO" TABLE*****/
                    if ($to == "c++")
                    {
                        $to = "Cplusplus";
                    }
                    elseif($to == "java")
                    {
                        $to = "Java";
                    }
                    elseif($to == "c")
                    {
                        $to = "C";
                    }
                    elseif($to == "c#")
                    {
                        $to = "Csharp";
                    }
                    elseif($to == "python")
                    {
                        $to = "Python";
                    }
                    if ($to != null)
                    {
                    // echo "Inside Java". "</br>";   
                         $Traduction = $conn->prepare("SELECT Languages.$to FROM
                         Languages WHERE ID = '$fIndex' ");
                         $Traduction ->execute();
                         $flag = $Traduction->setFetchMode (PDO :: FETCH_ASSOC);
                         $result3= $Traduction->fetchAll();

                         $row2 = $result3[0];
                         $fTraduction = $row2[$to];

                        if( $fTraduction == NULL){
                        $word = str_replace($word4, "No '  ". $word4. "  ' Equivalent", $word);
                        }
                        else{
                        // echo $fTraduction. " </br>";
                        $word = str_replace($word4, $fTraduction, $word);
                        }     
                    }
                   /****** END OF SEQUENCE OF IF_ELSE STATMENTS TO FIND THE TRANSLATION IN "TO" TABLE****/          
                  }
           }
            echo  nl2br($word);
        }
        else {
            
            echo "Incorrect Choice </br>";
        }
     
     
     
     
     
     
     
     
     
     
        $conn = null;
    }
    catch(PDOException $e){
        
        //echo "Connection failed: " . $e->getMessage();
        echo '<script language="javascript">';
        echo 'alert("Connection failed")';
        echo '</script>';
    }
?>