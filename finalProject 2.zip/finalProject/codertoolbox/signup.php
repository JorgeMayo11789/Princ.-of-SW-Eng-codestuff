
<?php include('signupdb.php') ?>

<!DOCTYPE html>
<html>
<body>

<header>Sign up</header>
   
 
    
 <!--SIGNUP FORM-->
   
 <div id="signupform">
    <form action="signup.php" method="post">
        <p>Please sign up to continue:</p>
        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" id="firstname" required/> <br>
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required/> <br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required/> <br>
        <input type="radio" name="type" value="student" required> Student
        <input type="radio" name="type" value="tutor" required> Tutor<br>
    
        <button type="submit" name="enter">Sign Up</button><br><br>
        
        <a href="login.php" id="login">I already have an account.</a>
    </form>
    </div>
       
    
</body>
</html>

