/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EditProduct;
import ProductList.Product;
import java.awt.Container;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
public class EditProductView extends JFrame{
JLabel l1, l2, l3,l4,l5;
Product p;
JTextField tname,tprice,tstock;
JButton btnConfirmEdits, btnRemove;
    public EditProductView(Product p)
    {
       this.p = p;
       l1 = new JLabel("Product ID:"+p.getID());
       l2 = new JLabel("Name:");
       l3 = new JLabel("Price:");
       l4 = new JLabel("Quantity: ");
       tname = new JTextField(p.getName());
       tprice = new JTextField(""+p.getCost());
       tstock = new JTextField(""+p.getquantity());
        btnConfirmEdits = new JButton("Confirm Edits");
        btnRemove = new JButton("Remove Product");
        Container c = getContentPane(); 
        c.setLayout(null); 
        c.add(l1);
        c.add(l2);
        c.add(l3);
        c.add(l4);
        c.add(tname);
        c.add(tprice);
        c.add(tstock);
        c.add(btnConfirmEdits);
        c.add(btnRemove);
        l1.setBounds(10, 10, 250, 20);
        l2.setBounds(10, 30, 250, 20);
        tname.setBounds(10,60,250,20);
        l3.setBounds(10,80, 250, 20);
        tprice.setBounds(10,110,250,20);
        l4.setBounds(10, 130, 250, 20);
        tstock.setBounds(10,160,250,20);
        //l5.setBounds(10, 210, 250, 20);
        btnConfirmEdits.setBounds(220, 300, 150, 50);
        btnRemove.setBounds(100,300,150,50);
        this.setLayout(null);
        this.setTitle("Table Example");
        this.setSize(400,400);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);    
    }
    public String getName()
    {
        return tname.getText();
    }
    public double getCost()
    {
        return Double.parseDouble(tprice.getText());
    }
    public int getStock()
    {
        return Integer.parseInt(tstock.getText());
    }
}
