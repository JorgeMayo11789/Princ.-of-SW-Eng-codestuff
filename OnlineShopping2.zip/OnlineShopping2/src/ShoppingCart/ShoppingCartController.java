/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShoppingCart;
import ProductList.ProductList;
import ProductList.Product;
import Order.*;
import Users.UserList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author jmayoral2017
 */
public class ShoppingCartController {
private ShoppingCartView scv;
private ShoppingCartModel scm;
private ProductList pl;
private CartList cl;
    public ShoppingCartController(ShoppingCartView scv, ShoppingCartModel scm,CartList cl,ProductList pl) {
         this.scm = scm;
        this.scv = scv;
        this.pl = pl;
        this.cl = cl;
      
        removeControl();
        orderControl();
    }
    public void removeControl()
    {
        scv.getTable().addMouseListener(new java.awt.event.MouseAdapter(){
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            int productID = Integer.parseInt(scv.getTable().getValueAt(scv.getTable().getSelectedRow(),0).toString());
            System.out.println(productID);
            Product p = pl.getProductFromID(productID);
            cl.removeFromCart(p);
            scv.updateTable();   
           
        }
        }
        );
    }
    public void orderControl()
    {
        scv.getOrderButton().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(cl.isEmpty() == true)
                {
                    System.out.println("Your shopping caert is empty");
                }
                else
                {
                 OrderModel om = new OrderModel(cl,scm);
                 OrderView ov = new OrderView();
                 OrderController oc = new OrderController(om,ov);
                }
                 
            }
            
        });
    }
}
            
             