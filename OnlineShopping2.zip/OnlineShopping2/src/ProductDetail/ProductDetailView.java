/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProductDetail;
import ProductList.Product;
import java.awt.Container;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
public class ProductDetailView extends JFrame{
JLabel l1, l2, l3,l4,l5,sliderlabel;
Product p;
JButton btnAddToCart;
JSlider slider;
private int min = 1;
private int max;
    public ProductDetailView(Product p)
    {
       this.p = p;
       max = p.getquantity();
       slider = new JSlider(min,max);
       l1 = new JLabel(p.getName());
        l2 = new JLabel("Product ID:"+p.getID());
        l3 = new JLabel("Price: "+p.getCost());
        l4 = new JLabel("Quantity: "+p.getquantity());
        l5 = new JLabel("Seller: "+p.getSeller());
        sliderlabel = new JLabel("1");
    	 btnAddToCart = new JButton("Add to Cart");
        Container c = getContentPane(); 
        c.setLayout(null); 
        c.add(l1);
        c.add(l2);
        c.add(l3);
        c.add(l4);
        c.add(l5);
        c.add(slider);
        c.add(btnAddToCart);
        c.add(sliderlabel);
        sliderlabel.setBounds(10,230,200,30);
        l1.setBounds(10, 10, 250, 10);
        l2.setBounds(10, 30, 250, 10);
        l3.setBounds(10, 50, 250, 20);
        l4.setBounds(10, 70, 250, 20);
        l5.setBounds(10, 90, 250, 20);
        slider.setBounds(10,250,100,30);
        btnAddToCart.setBounds(220, 300, 150, 50);
        this.setLayout(null);
        this.setTitle("Table Example");
        this.setSize(400,400);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);    
    }
    public void updateSliderLabel()
    {
        sliderlabel.setText(Integer.toString(slider.getValue()));
        sliderlabel.revalidate();
        sliderlabel.repaint();
        //System.out.println(sliderlabel.getText());
    }
    void updateQuantity() {
        max = p.getquantity();
        slider.setMaximum(max);
        slider.repaint();
    }
}
