
package ProductDetail;

public class ProductDetailModel {
    public ProductDetailModel()
    {
        
    }
}
