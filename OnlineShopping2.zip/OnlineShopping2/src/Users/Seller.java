/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

/**
 *
 * @author jmayoral2017
 */
public class Seller extends User{
    
    public Seller(String username, String password, String type) {
        super(username, password, type);
    }
    public Seller(Seller s)
    {
       super(s.user(),s.pass(),s.type()); 
    }
    public Seller(User u)
    {
         super(u.user(),u.pass(),u.type());
    }
    
    public double getRevenue()
    {
        return 0;
    }
    public void setRevenue(Double d)
    {
        
    }
}
