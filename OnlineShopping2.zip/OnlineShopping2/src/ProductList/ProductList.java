package ProductList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
public class ProductList {
	public ArrayList<Product> products = new ArrayList<Product>();
	public ProductList()
	{
        }
	public void addProduct(Product p)
        {
            products.add(p);
        }
        public void removeProduct(Product p) throws IOException
        {
            products.remove(p);
            updateProductFile();
        }
        public Product getProductFromID(int ID)
        {
            for(int i = 0;i<products.size();i++)
            {
                if(products.get(i).getID() == ID)
                {
                    return products.get(i);
                }
            }
            return null;
        }
   public  void printlist() {
        for(int i = 0;i<products.size();i++)
        {
            System.out.println(products.get(i).getID());
            System.out.println(products.get(i).getName());
            System.out.println(products.get(i).getCost());
            System.out.println(products.get(i).getquantity());
            System.out.println(products.get(i).getSeller());
        }
    }
    public int size() {
        return products.size();
    }
    public boolean checkforID(int id)
    {
        for(int i = 0;i<products.size();i++)
        {
            if(id == products.get(i).getID())
            {
                System.out.println("id already taken"+id+" and taken"+products.get(i).getID());
                return true;
            }
        }
        return false;
    }

    public void updateProductFile() throws IOException {
        int size = products.size();
		FileWriter fw = new FileWriter("src/products.txt");
		PrintWriter pw = new PrintWriter(fw);
		System.out.println(products.get(size-1).getID()+" "+products.get(size-1).getName()+" "+products.get(size-1).getquantity()+" "+products.get(size-1).getSeller());
		for(int i = 0;i<size;i++)
		{
			pw.println(products.get(i).getID()+" "+products.get(i).getName()+" "+products.get(i).getCost()+" "+products.get(i).getquantity()+" "+products.get(i).getSeller());
		}
		pw.close();
		fw.close();
    }
}
