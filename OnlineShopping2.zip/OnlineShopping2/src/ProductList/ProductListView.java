package ProductList;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class ProductListView extends JFrame
{
	JLabel l1, l2, l3;
	private JButton btnShop, btnLogout;
        ProductList pl = new ProductList();
        private JTable table = null;
        Container c;
    public ProductListView() throws FileNotFoundException
    {
    	 l1 = new JLabel("Welcome");
    	 l2 = new JLabel("Product List");
    	 btnShop = new JButton("Cart");
    	 btnLogout = new JButton("LogOut");
    	this.setLayout(new BorderLayout());
        //headers for the table
        String[] columns = new String[] {
            "Id", "Name", "Cost", "Quantity","Seller"
        };
        //actual data for the table in a 2d array
        ////////
        
        System.out.println("List of Users: Username, password, User type(Customer/Seller)");
		 File file = new File("src/products.txt");
		 BufferedReader br = new BufferedReader(new FileReader(file)); 
		  String st;
		  String[] split;
		  try {
			while ((st = br.readLine()) != null)
			{
                            split = st.split("\\s+");
			    Product p1 = new Product(Integer.parseInt(split[0]),split[1],Double.parseDouble(split[2]),Integer.parseInt(split[3]),split[4]);
                            pl.addProduct(p1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
                }
         Object[][] data = new Object[pl.size()][5];
         for(int i = 0;i<pl.size();i++)
         {
             data[i][0] = pl.products.get(i).getID();
             data[i][1] = pl.products.get(i).getName();
             data[i][2] = pl.products.get(i).getCost();
             data[i][3] = pl.products.get(i).getquantity();
             data[i][4] = pl.products.get(i).getSeller();
         }
        table = new JTable(data, columns);
        table.setDefaultEditor(Object.class, null);
        
        //table action listener
        
        c = getContentPane(); 
        c.setLayout(null); 
        JScrollPane scroller = new JScrollPane(table); 
        c.add(scroller); 
        scroller.setBounds(160, 100, 700, 300);
        c.add(l1);
        c.add(btnLogout);
        c.add(btnShop);
        l1.setBounds(450, 50, 100, 50);
        btnLogout.setBounds(880, 20, 100, 50);
        btnShop.setBounds(780, 20, 70, 50);
        this.setLayout(null);
        this.setTitle("Table Example");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //this.pack();
        this.setSize(1000,500);
        this.setLocationRelativeTo(null); 
        this.setVisible(true);
        
        btnShop.addActionListener(new ActionListener(){
                 @Override
                 public void actionPerformed(ActionEvent e) {
                     //ShoppingSystemMain.ShoppingCartView();
                 }
            
        });
        
    }
    public JTable getTable()
    {
        return table;
    }
    public JButton getCart()
    {
        return btnShop;
    }
    public JButton getLogout()
    {
        return btnLogout;
    }
    ProductList getProductList() {
        return pl;
    }
    public void updateTable()
    {
        
        Object[][] data = new Object[pl.size()][5];
         for(int i = 0;i<pl.size();i++)
         {
             data[i][0] = pl.products.get(i).getID();
             data[i][1] = pl.products.get(i).getName();
             data[i][2] = pl.products.get(i).getCost();
             data[i][3] = pl.products.get(i).getquantity();
             data[i][4] = pl.products.get(i).getSeller();
         }
         String[] columns = new String[] {
            "Id", "Name", "Cost", "Quantity","Seller"
        };
         DefaultTableModel dataModel = new DefaultTableModel(data, columns);
         c.remove(table);
        table.setModel(dataModel);
       c.revalidate();
       c.repaint();
        System.out.println("Table is being repainted yo");
    }
}
