package ProductList;

public class Product {
	private String name;
	private double cost;
	private int ID;
	private String Seller;
        private int quantity;
public Product(int ID, String name, double cost,int quantity, String Seller)
	{
            this.name = name;
            this.ID = ID;
            this.cost = cost;
            this.Seller = Seller;
            this.quantity = quantity;
	}
	public void setName(String name)
	{
            this.name = name;
	}
        public String getName()
        {
            return name;
        }
	public void setCost(double cost)
	{
		this.cost = cost;
	}
        public double getCost()
        {
            return cost;
        }
	public void setID(int ID)
	{
		this.ID = ID;
	}
        public int getID()
        {
            return ID;
        }
        public void setquantity(int quantity)
        {
            this.quantity = quantity;
        }
        public int getquantity()
        {
            return quantity;
        }
        public Product getProduct()
        {
            return this;
        }

    public String getSeller() {
       return Seller;
    }
}
