package Shoppingsystem;
import Inventory.InventoryController;
import Inventory.InventoryModel;
import Inventory.InventoryView;
import ProductList.ProductListController;
import ProductList.ProductListModel;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import ProductList.ProductListView;
import ShoppingCart.CartList;
import Users.UserList;
import Users.User;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import registerNewUser.RegisterController;
import registerNewUser.RegisterView;
import signin.*;
public class ShoppingSystemMain {
	static UserList l1 = new UserList();
        private CartList cartlist = new CartList();
        private int loop = 0;
        private User currentuser = null;
        public ShoppingSystemMain(UserList l1) throws FileNotFoundException, IOException
        {
            populateUserList();
            Login();
        }
        public void populateUserList() throws IOException
        {
            System.out.println("List of Users: Username, password, User type(Customer/Seller)");
            File file = new File("src/users.txt");
            BufferedReader br = new BufferedReader(new FileReader(file)); 
            String st;
            String[] split;
            try {
			while ((st = br.readLine()) != null)
			{
                            split = st.split("\\s+");
			    User u1 = new User(split[0], split[1], split[2]);
                            System.out.println(split[0]+" "+split[1]);
			    l1.addUser(u1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		  br.close();
        }
        public void Login() throws FileNotFoundException
        {
            while (loop == 0)
            {
                LoginModel m = new LoginModel(l1);
                LoginView v = new LoginView();
                LoginController c = new LoginController(m,v,l1);
                c.Register();
                while(c.Login() == 0)
                {
                    try {
                    Thread.sleep(1000);
                        } catch (InterruptedException ex) {
                    Logger.getLogger(ShoppingSystemMain.class.getName()).log(Level.SEVERE, null, ex);
                        }
                }
            switch(c.Login())
            {
                case 0:
                    
                    break;
                //customer
                case 1:
                     currentuser = c.getCurrentUser();
                     loop = 1;
                     ProductList();
                    break;
                //seller
                case 2:
                     currentuser = c.getCurrentUser();
                     loop = 1;
                     Inventory();
                    break;
                case 3:
                    Register();
                    break;
                        
            }
            }
        }
        public void ProductList() throws FileNotFoundException
        {
            ProductListModel pm = new ProductListModel();
            ProductListView pv = new ProductListView();
            ProductListController pc = new ProductListController(pv,pm,cartlist);
            pc.tableControl();
            pc.cartControl();
            while(pc.logoutControl() == false)
            {
                pc.logoutControl();
            }
        }
         public void Inventory() throws FileNotFoundException 
        {
            InventoryModel im = new InventoryModel();
            InventoryView iv = new InventoryView(currentuser);
            InventoryController ic = new InventoryController(iv,im,currentuser);
            ic.addNewProductButton();
            ic.tableControl();
            while(ic.logoutControl() == false)
            {
                ic.logoutControl();
            }
        }
         public void Register() throws FileNotFoundException
         {
                RegisterView rv = new RegisterView();
                RegisterController rc = new RegisterController(l1,rv);
                while(rc.confirmRegsitration() == 0)
                {
                     try {
                    Thread.sleep(500);
                    } catch (InterruptedException ex) {
                    Logger.getLogger(ShoppingSystemMain.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                System.out.println(rc.confirmRegsitration());
                if(rc.confirmRegsitration() == 1)
                {
                    currentuser = new User(rc.getEnteredUser(),rc.getEnteredPass(),rc.getType());
                    System.out.println(rc.getType());
                    System.out.println("New user created");
                    loop = 1;
                    if(rc.getType() == "Customer")
                    {
                        System.out.println("Type is customer");
                        ProductList();
                    }
                    else
                    {
                        System.out.println("Type is not3 customer");
                        Inventory();
                    }
                    
                }
                else if(rc.confirmRegsitration() == -1)
                {
                    System.out.println("Cancel button pressed");
                }
         }
	public static void main(String[] args) throws IOException
	{
            while(0 == 0)
            {
                 ShoppingSystemMain s = new ShoppingSystemMain(l1);
		 System.out.println();
            }
		 
        }
}
