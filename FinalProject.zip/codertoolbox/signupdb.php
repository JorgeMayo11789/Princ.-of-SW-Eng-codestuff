<!--INFORMATION HANDLING-->

<?php
    
//CONNECT TO BD
session_start();
include('io_db_connect.php');
   
    
//IF CONNECTION SUCCESSFUL 
if(isset($_POST['enter']))
{ 
    global $mysqli, $username;
    
    //VARIABLES    
    $firstname = $mysqli->real_escape_string($_POST['firstname']);
    $username = $mysqli->real_escape_string($_POST['username']);
    $salt1 = "qm&h*"; $salt2 = "pg!@";
    $token = $_POST['password'];
    $password = hash('ripemd128', "$salt1$token$salt2"); 
    $type = $mysqli->real_escape_string($_POST['type']);
    $query = "SELECT Username FROM Users where Username='".$username."'";
    $result = mysqli_query($mysqli,$query);
    $numResults = mysqli_num_rows($result);
       
    
    
    if($numResults>=1)
    {
        $message = $username." Username already exist!!";
        
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
    else
    {
        mysqli_query($mysqli, "INSERT INTO Users(FirstName, Username, Password, Type) values('$firstname','$username','$password','$type' )");
        
        $message = "Signup Sucessfully!!";
        
        echo "<script type='text/javascript'>alert('$message');</script>";
        
        header("location: ../homepage/index.php");
        
    }
        
}

   
    
$mysqli->close();
?> 