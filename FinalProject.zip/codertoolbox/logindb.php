<!--INFORMATION HANDLING-->

<?php
//CONNECT TO BD
session_start();
include('io_db_connect.php');
   
    
//IF CONNECTION SUCCESSFUL 
if(isset($_POST['login_enter']))
{
    
$username = mysqli_real_escape_string($mysqli,$_POST['username']);

    
$salt1 = "qm&h*"; $salt2 = "pg!@";
$token = $_POST['password'];
$password = hash('ripemd128', "$salt1$token$salt2"); 
    
   
    
$strSQL = mysqli_query($mysqli,"SELECT Username FROM Users WHERE Username='$username' and Password='$password'");
$Results = mysqli_fetch_array($strSQL);

    
if(count($Results)>=1)
    {
    $message = $Results['Username']." Login Sucessfully!!";
    
    
    echo "<script type='text/javascript'>alert('$message');</script>";

    header("location: ../homepage/index.php"); 
  
           
    }
else
    {
            $message = "Invalid email or password!!";
            
             echo "<script type='text/javascript'>alert('$message');</script>";
            
            
        }        
    
}
$mysqli->close();
?>
