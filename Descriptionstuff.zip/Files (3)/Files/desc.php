<?php 
//Database connection
 try{
        $servername = "localhost";
        //CONNECT TO DATABASE
        $username = "jmayoral2017";
        $password = "gQ52FJ9MRr";
        $conn = new
        PDO ("mysql:host=$servername;dbname=jmayoral2017", trim($username), trim($password));
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO :: ERRMODE_EXCEPTION);
        $from = $_POST['postfrom'];
        $to = $_POST['postto'];
        $word = $_POST['postword'];
     //echo '<script language="javascript">';
      //  echo 'alert($from)';
       // echo '</script>';
     /*************************************************************  From  ***************************************************/
        if($from == "c++")
        {
           $from = "Cplusplusdesc";
        }
        elseif($from == "java")
        {
            $from = "Javadesc";
        }
       elseif($from == "c")
        {
            $from = "Cdesc";
        }
         elseif($from == "c#")
        {
            $from = "Csharpdesc";
        }
      elseif($from == "python")
        {
            $from = "Pythondesc";
        }
          
        if ($from != null){
          /******FIND THE INDEX FROM TABLE*****/
            
            $index = $conn->prepare("SELECT $from.ID FROM
            $from WHERE $from.keyword = '$word'");
            $index->execute();
            $flag = $index->setFetchMode (PDO :: FETCH_ASSOC);
            $result2= $index->fetchAll();
            $row1   = '';
            $fIndex = '';
            
            if (count($result2) == 0 ){
                echo "Incorrect Input";
                
            }
            else{
                
              $row1 = $result2[0];  
              $fIndex = $row1["ID"];       
            /******SEQUENCE OF IF_ELSE STATMENTS TO FIND THE TRANSLATION IN "TO" TABLE*****/
            if ($to == "c++")
            {
                $to = "Cplusplusdesc";
            }
            elseif($to == "java")
            {
                $to = "Javadesc";
            }
            elseif($to == "c")
            {
                $to = "Cdesc";
            }
            elseif($to == "c#")
            {
                $to = "Csharpdesc";
            }
            elseif($to == "python")
            {
                $to = "Pythondesc";
            }
            if ($to != null)
            {
            // echo "Inside Java". "</br>";   
                 $Traduction = $conn->prepare("SELECT $from.description FROM
                 $from WHERE ID = '$fIndex' ");
                 $Traduction ->execute();
                 $flag = $Traduction->setFetchMode (PDO :: FETCH_ASSOC);
                 $result3= $Traduction->fetchAll();
                
                 $row2 = $result3[0];
                 $fTraduction = $row2["description"];
                
                if( $fTraduction === NULL){
                 echo "No $from Equivalent </br>";
                }
                else{
                 echo $fTraduction. " </br>";    
                }     
            }
           /****** END OF SEQUENCE OF IF_ELSE STATMENTS TO FIND THE TRANSLATION IN "TO" TABLE*****/          
          }
        }
        else {
            
            echo "Incorrect Choice </br>";
        }
        $conn = null;
    }
    catch(PDOException $e){
        
        //echo "Connection failed: " . $e->getMessage();
        echo '<script language="javascript">';
        echo 'alert("Connection failed")';
        echo '</script>';
    }
?>