<?php 

session_start();

//Connect to database


// Do not change the following two lines.
$teamURL = dirname($_SERVER['PHP_SELF']) . DIRECTORY_SEPARATOR;
$server_root = dirname($_SERVER['PHP_SELF']);

// You will need to require this file on EVERY php file that uses the database.
// Be sure to use $db->close(); at the end of each php file that includes this!

$dbhost = 'localhost';  // Most likely will not need to be changed
$dbname = 'iosias';   // Needs to be changed to your designated table database name
$dbuser = 'iosias';   // Needs to be changed to reflect your LAMP server credentials
$dbpass = 'eileen11'; // Needs to be changed to reflect your LAMP server credentials

$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if($mysqli->connect_errno > 0) {
    die('Unable to connect to database [' . $mysqli->connect_error . ']');
}

// Connect to database number 2

$dbhost2 = 'localhost';  // Most likely will not need to be changed
$dbname2 = 'ankeze2016';   // Needs to be changed to your designated table database name
$dbuser2 = 'ankeze2016';   // Needs to be changed to reflect your LAMP server credentials
$dbpass2 = 'flavien2012'; // Needs to be changed to reflect your LAMP server credentials

$mysqli2 = new mysqli($dbhost2, $dbuser2, $dbpass2, $dbname2);

if($mysqli2->connect_errno > 0) {
    die('Unable to connect to database [' . $mysqli2->connect_error . ']');
}






//Check if the user is logged in
function isLoggedIn()
{
	if (isset($_SESSION['user'])) {
		return true;
	}else{
		return false;
	}
}

//Check if it is Tutor
function isTutor()
{
	if (isset($_SESSION['user']) && $_SESSION['user']['Type'] == 'tutor' ) {
		return true;
	}else{
		return false;
	}
}

//Check if it is Student
function isStudent()
{
	if (isset($_SESSION['user']) && $_SESSION['user']['Type'] == 'student' ) {
		return true;
	}else{
		return false;
	}
}



?>