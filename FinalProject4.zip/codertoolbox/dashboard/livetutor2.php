<?php 
include('../homepage/functions.php');



    if ( !isLoggedIn() ) {
        //$_SESSION['msg'] = "You must log in first";
        header('location: ../homepage/index.php');
        exit();
    }

 







/*if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: ../login.php");
} */





?>




<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student - Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
    
      <!-- Boxa -->
      <link href="stylebox.css" rel="stylesheet">
      
      
     

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="../homepage/index.php">Coder's Toolbox</a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

      <!-- Navbar Search -->
      <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
        <div class="input-group">
            
            
          <div class="input-group-append">
            
          </div>
        </div>
      </form>

      <!-- Navbar -->
      <ul class="navbar-nav ml-auto ml-md-0">
       
    <li class="navbar-brand mr-1" ><p>Welcome!</p></li>

        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user-circle fa-fw"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            
            <a class="dropdown-item" href="logout.php" >Logout</a>
          </div>
        </li>
      </ul>

    </nav>
    <div id="wrapper">

      <!-- Sidebar Student -->
        
      <?php if( $_SESSION['user']['Type'] == 'student'){ ?>  
        
        
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="student.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
    
        <li class="nav-item ">
          <a class="nav-link" href="keywordtranslator.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Keyword Translator</span></a>
        </li>
          
        <li class="nav-item">
          <a class="nav-link" href="codeconverter.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Code Converter</span></a>
        </li>
          
            <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Live Online Compiler</span>
          </a>
        </li>
    
        <li class="nav-item active">
          <a class="nav-link" href="livetutor.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Live Tutor</span></a>
        </li>
          
        <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="fas fa-fw fa-table"></i>
            <span>Schedule Tutor Session</span></a>
        </li>
      </ul>
        
       <!-- Sidebar Tutor --> 
        
       <?php }else{ ?> 
        
        <ul class="sidebar navbar-nav">
          
        <li class="nav-item">
          <a class="nav-link" href="tutor.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
    
        <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Schedule</span></a>
        </li>
          
        <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="fas fa-fw fa-table"></i>
            <span>Session</span></a>
        </li>
            
        <li class="nav-item active">
          <a class="nav-link" href="livetutor.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Live Tutor</span></a>
        </li> 
            
        <li class="nav-item">
          <a class="nav-link" href="tutorschedule.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span> Add Availability</span></a>
        </li>
          
         <li class="nav-item">
          <a class="nav-link" href="tutorcurrentschedule.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Current Availability </span></a>
        </li> 
          
          
            
      </ul>
      
        <?php } ?>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
       
        
        
        
        

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>
         
            
<!--LIVE TUTOR HTML-->         
      
           
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
    
<script type="text/javascript">
// jQuery Document
$(document).ready(function(){});
</script>
    
<!--CREATE THE LOGIN FORM-->
<?php

echo 'Welcome   '. $_SESSION['user']['FirstName'].'!'; 
            
function loginForm(){
    echo'
    <div id="loginform">
    <form action="livetutor2.php" method="post">
        <p>Please press enter to connect to a tutor:</p>
        
        <input type="submit" name="enter" id="enter" value="Enter" />
    </form>
    </div>
    ';
}   

?>
            
  
    
<!--SHOW THE LOGIN FORM OR CHAT SESSION-->
<?php
if(!isset($_POST['enter'])){
    
        $_SESSION['name'] = stripslashes(htmlspecialchars($_SESSION['user']['FirstName']));
    
    loginForm();
}
else{
?>
           
            
<div id="wrapper2">
    <div id="menu">
        <p class="welcome">Welcome, <b><?php echo $_SESSION['name']; ?></b></p>
        <p class="logout"><a id="exit" href="#">Exit Chat</a></p>
        <div style="clear:both"></div>
    </div>    
    <div id="chatbox"> 
    <br>    
    <!--POST WELCOME MESSAGE-->

        
    <!--POST MESSAGE-->
    <?php
     if(file_exists("log.html") && filesize("log.html") > 0){
    $handle = fopen("log.html", "r");
    $contents = fread($handle, filesize("log.html"));
    fclose($handle);
    echo $contents;}
        ?>
        
        
        
    </div>
    
    <br> 
    <form name="message" action="post2.php">
        <input name="usermsg" type="text" id="usermsg" size="63" />
        <input name="submitmsg" type="submit"  id="submitmsg" value="Send" />
    </form>
   
</div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
    
<script type="text/javascript">
// jQuery Document
$(document).ready(function(){
});
</script>
<?php
}
?>
 
 <!--WELCOME AND LOGOUT MENU-->

    
 <!--EXIT ALERT-->
<script type="text/javascript">
// jQuery Document
$(document).ready(function(){
	//If user wants to end session
	$("#exit").click(function(){
		var exit = confirm("Are you sure you want to end the session?");
		if(exit==true){
            window.location = 'livetutor2.php?logout=true';
            
        }		
	});
});

$("#submitmsg").click(function(){	
		var clientmsg = $("#usermsg").val();
		$.post("post2.php", {text: clientmsg});	
    
		$('#usermsg').val("");
    
    
		return false;
	});    
</script>

  <!--LOGOUT AND END SESSION-->   
<?php    
if(isset($_GET['logout'])){ 
     
    //Simple exit message
    $fp = fopen("log.html", 'a');
    fwrite($fp, "<div class='msgln'><i>User ". $_SESSION['name'] ." has left the chat session.</i><br></div>");
    file_put_contents("log.html","");
    fclose($fp);
      
    //session_destroy();
    //header("Location: student.php"); //Redirect the user
}
?>    
    

<!--DISPLAY FORM-->       
<script>    
function loadLog(){		

		$.ajax({
			url: "log.html",
			cache: false,
			success: function(html){		
				$("#chatbox").html(html); //Insert chat log into the #chatbox div				
		  	},
		});
	} 
    setInterval (loadLog, 2500);
</script> 
            
                  

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

  </body>

</html>