<?php 
//Database connection
        //$servername = "localhost";
        //CONNECT TO DATABASE
        //$username = "jmayoral2017";
        //$password = "gQ52FJ9MRr";
        //$conn = new mysqli($servername, $username, $password, $username);
     
    
   


    //Connect to database 2

$dbhost2 = 'localhost';  // Most likely will not need to be changed
$dbname2 = 'ankeze2016';   // Needs to be changed to your designated table database name
$dbuser2 = 'ankeze2016';   // Needs to be changed to reflect your LAMP server credentials
$dbpass2 = 'flavien2012'; // Needs to be changed to reflect your LAMP server credentials

$mysqli2 = new mysqli($dbhost2, $dbuser2, $dbpass2, $dbname2);

if($mysqli2->connect_errno > 0) {
    die('Unable to connect to database [' . $mysqli2->connect_error . ']');
}




        $tutorname   = $_SESSION['user']['FirstName'];
        $tutorid   =   $_SESSION['user']['ID'];
       

     /*************************************************************  From  ***************************************************/
     /******INSERT NEW SCHEDULE IN TABLE*****/

//IF CONNECTION SUCCESSFUL 
if(isset($_POST['add']))
{ 
    global $mysqli2, $mysqli, $username, $tutorid;
    
    
     $eventName   = $_POST['inputName'];
     $day         = $_POST['inputDay'];
     $times       = $_POST['inputTimes'];
     $description = $_POST['inputDescription'];
    
    
    
    //VARIABLES    
   /* $firstname = $mysqli->real_escape_string($_POST['firstname']);
    $username = $mysqli->real_escape_string($_POST['username']);
    $salt1 = "qm&h*"; $salt2 = "pg!@";
    $token = $_POST['password'];
    $password = hash('ripemd128', "$salt1$token$salt2"); 
    $type = $mysqli->real_escape_string($_POST['type']);
    $query = "SELECT Username FROM Users where Username='".$username."'";
    $result = mysqli_query($mysqli,$query);
    $numResults = mysqli_num_rows($result); */
       
    
    
  /*  if($numResults>=1)
    {
        $message = $username." Username already exist!!";
        
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
    else
    { */
    
    
        mysqli_query($mysqli2, "INSERT INTO availabilityShcedule(EventName, CreatedById, Days, Times, TDescription) values('$eventName','$tutorid','$day','$times','$description' )");
        
        $message = "Added Sucessfully!!";
        
        echo "<script type='text/javascript'>alert('$message');</script>";
        header('location: ../dashboard/tutor.php');
        //  header("location: ../homepage/index.php");
       
      /*  $strSQL = mysqli_query($mysqli,"SELECT * FROM Users WHERE Username='$username' and Password='$password'");
        $Results = mysqli_fetch_array($strSQL); 
        
        
        
        
        
        // check if user is tutor or student
        // $logged_in_user = mysqli_fetch_assoc($strSQL);
        if ($Results['Type'] == 'tutor') {

            $_SESSION['user'] = $Results;
            $_SESSION['success']  = "You are now logged in";
            header('location: ../dashboard/tutor.php');		  
        }
        else{

            $_SESSION['user'] = $Results;
            $_SESSION['success']  = "You are now logged in";

            header('location: ../dashboard/student.php');
        } 
        
        
    } */
        
}
























             
 //   $sql =   ("INSERT INTO Schedule (TutorName, Day, Times) VALUES ('$tutorname', '$days','$times')");

 //   $id =   ("SELECT ID FROM Schedule WHERE (TutorName = '$tutorname' AND Day = '$days' AND Times = '$times')");

             
//if ($mysqli->query($sql) === TRUE ) {
  	 
    
    
    
    
//	} else {
//	    echo "Error: " . $sql . "<br>" . $conn->error;
//	}

?>