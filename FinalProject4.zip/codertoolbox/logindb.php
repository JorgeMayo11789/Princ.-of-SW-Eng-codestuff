<!--INFORMATION HANDLING-->

<?php
//CONNECT TO BD
session_start();
include('io_db_connect.php');
   
    
//IF CONNECTION SUCCESSFUL 
if(isset($_POST['login_enter']))
{
    
$username = mysqli_real_escape_string($mysqli,$_POST['username']);

    
$salt1 = "qm&h*"; $salt2 = "pg!@";
$token = $_POST['password'];
$password = hash('ripemd128', "$salt1$token$salt2"); 
    
   
 /**************************************** Axel's Change*****************************/   
$strSQL = mysqli_query($mysqli,"SELECT * FROM Users WHERE Username='$username' and Password='$password'");
$Results = mysqli_fetch_array($strSQL);

    
if(count($Results)>=1){
    
  //  $message = $Results['Username']." Login Sucessfully!!";
       
  //  echo "<script type='text/javascript'>alert('$message');</script>";
    
  //  $logged_in_user = mysqli_fetch_assoc($strSQL);
  //  $message = $Results['Type']." Login Sucessfully!!";
  //  echo "<script type='text/javascript'>alert('$message');</script>";
    
    
  /**************************************** Axel's Change*****************************/ 
    
    
    // check if user is tutor or student
   // $logged_in_user = mysqli_fetch_assoc($strSQL);
    if ($Results['Type'] == 'tutor') {

        $_SESSION['user'] = $Results;
        $_SESSION['success']  = "You are now logged in";
        header('location: ../dashboard/tutor.php');		  
    }
    else{
        
        $_SESSION['user'] = $Results;
        $_SESSION['success']  = "You are now logged in";

        header('location: ../dashboard/student.php');
    }
    
    /**************************************** Axel's Change*****************************/
   // header("location: ../homepage/index.php"); 
  
           
    }
else
    {
            $message = "Invalid email or password!!";
            
             echo "<script type='text/javascript'>alert('$message');</script>";
            
            
        }        
    
}
$mysqli->close();
?>
